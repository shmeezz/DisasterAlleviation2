﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Disaster_Management_Website
{
    public class Database
    {
        public string database = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\X270\Desktop\disasterAlleviation.mdf;Integrated Security=True;Connect Timeout=30";
    }
}

﻿namespace DisasterAlleviation2022_version_2.Models
{
    public class Donations
    {
        public int Id { get; set; }
        public double Amount { get; set; }
        public DateTime DateTime { get; set; }
        public string DonorName { get; set; }

        public Donations()
        {
                                    
        }
    }
}

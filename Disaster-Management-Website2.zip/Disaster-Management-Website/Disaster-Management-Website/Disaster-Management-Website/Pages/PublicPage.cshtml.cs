using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Disaster_Management_Website.Pages
{
    public class PublicPageModel : PageModel
    {
        public List<PublicView> getP = new List<PublicView>();
        public List<Total> getTotal = new List<Total>();
        public string hasData;
        public static SqlConnection sqlConnect;
        public static SqlCommand sqlCommand;
        SqlDataReader sqlData;
        public static string query = "";

        public void OnGet()
        {
            try
            {
                String getMoney = calculatedMoney(sqlConnect, sqlCommand, sqlData, query);
                string getGoods = calculateGoods(sqlConnect, sqlCommand, sqlData, query);
                getTotal.Add(new Total(getMoney, getGoods));


                Database conn = new Database();
                sqlConnect = new SqlConnection(conn.database);

                sqlConnect.Open();
                query = "select d.*, a.* from DISASTER D inner join AllocateMoney A on d.DISASTER_ID=a.DISASTER_ID";
                sqlCommand = new SqlCommand(query, sqlConnect);
                sqlData = sqlCommand.ExecuteReader();

                string status = "Active";
                while (sqlData.Read())
                {
                    getP = activeDisaster(sqlData, status);
                }
                sqlConnect.Close();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.ToString());
            }
        }

        public List<PublicView> activeDisaster(SqlDataReader sqlData, string status)
        {
            getP.Add(new PublicView(sqlData["DISASTER_ID"].ToString(), sqlData["STARTING_DATE"].ToString(), sqlData["ENDING_DATE"].ToString(), sqlData["LOCATION"].ToString(), sqlData["DISASTER_DESCRIPTION"].ToString(), sqlData["AID"].ToString(), sqlData["NEW_AID"].ToString(), sqlData["Goods"].ToString(), status));

            return getP;
        }

        private string calculateGoods(SqlConnection sqlConnect, SqlCommand sqlCommand, SqlDataReader sqlData, string query)
        {
            double val1 = 0;
            try
            {

                Database conn = new Database();
                sqlConnect = new SqlConnection(conn.database);
                sqlConnect.Open();
                query = "select* from goods";
                sqlCommand = new SqlCommand(query, sqlConnect);
                sqlData = sqlCommand.ExecuteReader();
                while (sqlData.Read())
                {
                    val1 += Convert.ToDouble(sqlData["Number_of_item"].ToString());
                }
                sqlConnect.Close();

            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.ToString());
            }

            return val1.ToString();
        }

        private string calculatedMoney(SqlConnection sqlConnect, SqlCommand sqlCommand, SqlDataReader sqlData, string query)
        {
            double val1 = 0;
            try
            {

                Database conn = new Database();
                sqlConnect = new SqlConnection(conn.database);
                sqlConnect.Open();
                query = "select* from Money_ ";
                sqlCommand = new SqlCommand(query, sqlConnect);
                sqlData = sqlCommand.ExecuteReader();
                while (sqlData.Read())
                {
                    val1 += Convert.ToDouble(sqlData["amount"].ToString());
                }
                sqlConnect.Close();

            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.ToString());
            }

            return val1.ToString();
        }
    }

    public class Total
    {

        public string totalMoney;
        public string totalGoods;

        public Total()
        {

        }
        public Total(String money, String goods)
        {
            this.totalMoney = money;
            this.totalGoods = goods;
        }
        public String getTotalMoney()
        {
            return this.totalMoney;
        }
        public String getTotalGoods()
        {
            return this.totalGoods;
        }
    }

    public class PublicView
    {
        public string rowID;
        public string startDate;
        public string endDate;
        public string location;
        public string description;
        public string Aid;
        public string newAid;
        private string money;
        public string status;

        public PublicView()
        {

        }
        public PublicView(string row, string start, string end, string location, string description, string aid, string newAid, string money, string status)
        {
            this.rowID = row;
            this.startDate = start;
            this.endDate = end;
            this.location = location;
            this.description = description;
            this.Aid = aid;
            this.newAid = newAid;
            this.money = money;
            this.status = status;
        }

        public string getRow()
        {
            return rowID;
        }
        public string getStartDate()
        {
            return startDate;
        }
        public string getEndDate()
        {
            return endDate;
        }
        public string getLocation()
        {
            return location;
        }
        public string getDescription()
        {
            return description;
        }
        public string getAid()
        {
            return Aid;
        }
        public string getNewAid()
        {
            return newAid;
        }
        public string getMoney()
        {
            return money;
        }
        public string getStatus()
        {
            return status;
        }
    }

}



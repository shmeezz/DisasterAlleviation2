using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Disaster_Management_Website.Pages
{
    public class GoodsModel : PageModel
    {
        public List<Goods> getClass = new List<Goods>();
        public string hasData;
        public static SqlConnection sqlConnect;
        public static SqlCommand sqlCommand;
        SqlDataReader sqlData;
        public static string query = "";
        public void OnGet()
        {
            try
            {
                Database conn = new Database();
                sqlConnect = new SqlConnection(conn.database);

                sqlConnect.Open();
                query = "select* from GOODS  where LOGIN_ID='" + LoginUserModel.user_ID + "'";
                sqlCommand = new SqlCommand(query, sqlConnect);
                sqlData = sqlCommand.ExecuteReader();

                while (sqlData.Read())
                {
                    getClass = View_Goods(sqlData);
                }
                sqlConnect.Close();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.ToString());
            }
        }

        public List<Goods> View_Goods(SqlDataReader sqlData)
        {
            getClass.Add(new Goods(sqlData["GOODS_ID"].ToString(), sqlData["NUMBER_OF_ITEM"].ToString(), sqlData["CATEGORY"].ToString(), sqlData["NEW_CATEGORY"].ToString(), sqlData["DATE_ITEM"].ToString()));
            return getClass;
        }
    }
    public class Goods
    {
        public string ID;
        public string NumberOfItem;
        public string Category;
        public string NewCategory;
        public string date;
        public Goods()
        {

        }
        public Goods(string row, string date, string amount, string ann, string Ndate)
        {
            this.ID = row;
            this.NumberOfItem = date;
            this.Category = amount;
            this.NewCategory = ann;
            this.date = Ndate;
        }

        public string getRow()
        {
            return ID;
        }
        public string getNumber()
        {
            return NumberOfItem;
        }
        public string getCategory()
        {
            return Category;
        }
        public string getNewCategory()
        {
            return NewCategory;
        }
        public string getDate()
        {
            return date;
        }

    }
}

﻿namespace DisasterAlleviation2022_version_2.Models
{
    public class Disaster
    {
        public int Id { get; set; }
        
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string location { get; set; }
        public string RequiredAidType { get; set; }

        public Disaster()
        {

        }
    }
}

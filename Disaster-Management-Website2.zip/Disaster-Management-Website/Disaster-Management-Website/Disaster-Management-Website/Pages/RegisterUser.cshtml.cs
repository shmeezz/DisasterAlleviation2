using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Disaster_Management_Website.Pages
{
    public class RegisterUserModel : PageModel
    {

        public bool hasData = false;
        public string first_name = "";
        public string second_name = "";
        public string gender = "";
        public string email = "";
        public string password = "";

        public static SqlConnection sqlConnect;
        public static SqlCommand sqlCommand;
        public static string query = "";

        public void OnGet()
        {
        }
        public void OnPost()
        {
            hasData = true;
            first_name = Request.Form["fname"];
            second_name = Request.Form["sname"];
            gender = Request.Form["txtGender"];
            email = Request.Form["txtEmail"];
            password = Request.Form["txtPassword"];

            Database conn = new Database();
            Asymetry hash = new Asymetry();
            sqlConnect = new SqlConnection(conn.database);

            sqlConnect.Open();
            query = "INSERT INTO LOGINS VALUES('" + first_name + "','" + second_name + "','" + gender + "','" + email + "','" + hash.getHash(password) + "')";
            sqlCommand = new SqlCommand(query, sqlConnect);
            sqlCommand.ExecuteNonQuery();
            sqlConnect.Close();
        }
        public static bool checkPassword(string password)
        {
            if (password.Length > 8)
            {
                return true;
            }
            else
            {
                Console.WriteLine("password is Invalid");
                return false;
            }
        }

        public static bool checkEmail(string email)
        {
            if (Regex.Match(email, @"[A-Za-z]").Success)
            {
                return true;
            }
            else
            {
                Console.WriteLine("username is Invalid");
                return false;
            }
        }

        public static bool checkSecond(string second_name)
        {
            if (Regex.Match(second_name, @"[A-Za-z]").Success)
            {
                return true;
            }
            else
            {
                Console.WriteLine("second name is Invalid");
                return false;
            }
        }

        public static bool checkFirst(string first_name)
        {
            if (Regex.Match(first_name, @"[A-Za-z]").Success)
            {
                return true;
            }
            else
            {
                Console.WriteLine("first name is Invalid");
                return false;
            }
        }

    }

}

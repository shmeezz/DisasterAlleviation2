using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Disaster_Management_Website.Pages
{
    public class AddMoneyModel : PageModel
    {
        public bool hasData = false;
        public string date = "";
        public string anonymous = "";
        public string comment = "";
        public double amount = 0.0;

        //connections 
        public static SqlConnection sqlConnect;
        public static SqlCommand sqlCommand;
        public static string query = "";

        public void OnGet()
        {
        }
        public void OnPost()
        {
            try
            {
                hasData = true;
                date = Request.Form["fDate"];
                amount = Convert.ToDouble(Request.Form["fAmount"]);
                anonymous = Request.Form["fAno"];
                comment = Request.Form["fComment"];
                Database conn = new Database();
                sqlConnect = new SqlConnection(conn.database);

                sqlConnect.Open();
                query = "INSERT INTO MONEY_ VALUES('" + date + "','" + amount + "','" + anonymous + "','" + comment + "','" + LoginUserModel.user_ID + "')";
                sqlCommand = new SqlCommand(query, sqlConnect);
                sqlCommand.ExecuteNonQuery();
                sqlConnect.Close();
            }
            catch
            {
                Console.WriteLine("Please start by login first");
            }
        }
    }
}

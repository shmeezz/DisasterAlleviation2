using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Disaster_Management_Website.Pages
{
    public class LoginUserModel : PageModel
    {
        public bool hasData = false;
        public string email = "";
        public string password = "";
        public static int user_ID;

        public SqlConnection sqlConnect;
        public SqlCommand sqlCommand;
        public SqlDataReader sqlData;
        public static string query = "";

        public void OnPost()
        {
            hasData = true;
            email = Request.Form["txtEmail"];
            password = Request.Form["txtPassword"];

            //validate
            Database conn = new Database();
            Asymetry hash = new Asymetry();
            sqlConnect = new SqlConnection(conn.database);

            sqlConnect.Open();
            query = "SELECT* FROM LOGINS WHERE EMAIL='" + email + "' AND ACCOUNT_PASSWORD='" + hash.getHash(password) + "'";
            sqlCommand = new SqlCommand(query, sqlConnect);
            sqlData = sqlCommand.ExecuteReader();

            if (sqlData.Read())
            {
                user_ID = Convert.ToInt32(sqlData["LOGIN_ID"].ToString());
            }
            else
            {

            }
            sqlConnect.Close();
        }

        public static Boolean checkUserPassword(string password)
        {
            if (password.Length > 8)
            {
                return true;
            }
            else
            {
                Console.WriteLine("password is Invalid");
                return false;
            }
        }

        public static Boolean checkuserName(string email)
        {
            if (Regex.Match(email, @"[A-Za-z]").Success)
            {
                return true;
            }
            else
            {
                Console.WriteLine("username is Invalid");
                return false;
            }

        }
    }
}

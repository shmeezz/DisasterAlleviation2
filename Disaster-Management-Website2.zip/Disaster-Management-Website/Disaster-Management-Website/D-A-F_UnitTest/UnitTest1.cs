using NUnit.Framework;
using Disaster_Management_Website.Pages;

namespace D_A_F_UnitTest
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        
        [Test]
        public void ListOfDisaster()
        {
            Disaster goods = new Disaster();
            DisasterModel v = new DisasterModel();
            v.getClass.Add(new Disaster("1", "2020-01-03", "2023-01-03", "Kzn", "Floods", "Food", ""));
            v.getClass.Add(new Disaster("2", "2021-01-03", "2023-01-03", "Johannesburg", "Volcano", "Clothes", ""));
            Assert.IsNotNull(v);
        }
        [Test]
        public void ListOfDonatedMoney()
        {
            Money goods = new Money();
            MoneyModel v = new MoneyModel();
            v.getClass.Add(new Money("1", "2020-01-03", "R 30000", "NO", "For Clothes"));
            v.getClass.Add(new Money("2", "2021-01-03", "R 40000", "Yes", "For Food"));

            Assert.IsNotNull(v);
        }
        [Test]
        public void tListOfDonatedGoods()
        {
            Goods goods = new Goods();
            GoodsModel v = new GoodsModel();
            v.getClass.Add(new Goods("1", "2020-01-03", "R 30000", "Clothes", "2021-02-08"));
            v.getClass.Add(new Goods("2", "2021-01-03", "R 40000", "Other", "2022-02-08"));

            Assert.IsNotNull(v);
        }

        [Test]
        public void tPassword()
        {
            bool flag = true;
            string password = "www1234566";
            bool getFunction = LoginUserModel.checkUserPassword(password);

            Assert.AreEqual(flag, getFunction);

        }
        [Test]
        public void testWrongPassword()
        {
            bool flag = false;
            string password = "www";
            bool getFunction = LoginUserModel.checkUserPassword(password);

            Assert.AreEqual(flag, getFunction);

        }
        [Test]
        public void Email()
        {
            bool flag = true;
            string email = "jacob@gmail.yahoo";
            bool getFunction = LoginUserModel.checkuserName(email);

            Assert.AreEqual(flag, getFunction);

        }
        [Test]
        public void WrongEmail()
        {
            bool flag = false;
            string email = "@&@&&@&@&@&@&*@*@";
            bool getFunction = LoginUserModel.checkuserName(email);

            Assert.AreEqual(flag, getFunction);

        }

        [Test]
        public void registerEmail()
        {
            bool flag = true;
            string email = "jacob@gmail.com";
            bool getFunction = RegisterUserModel.checkEmail(email);

            Assert.AreEqual(flag, getFunction);

        }

        [Test]
        public void falseRegisterEmail()
        {
            bool flag = false;
            string email = "@&@&&@&@&@&@&*@*@";
            bool getFunction = RegisterUserModel.checkEmail(email);

            Assert.AreEqual(flag, getFunction);
        }


        [Test]
        public void registerFirstName()
        {
            bool flag = true;
            string name = "Jacob";
            bool getFunction = RegisterUserModel.checkFirst(name);

            Assert.AreEqual(flag, getFunction);
        }

        [Test]
        public void falseFirstName()
        {
            bool flag = false;
            string name = "@&@&&@&@&@&@&*@*@";
            bool getFunction = RegisterUserModel.checkEmail(name);

            Assert.AreEqual(flag, getFunction);
        }

        [Test]
        public void falseSecondName()
        {
            bool flag = false;
            string name = "*@&@&&@&@&@&@&*@*@";
            bool getFunction = RegisterUserModel.checkFirst(name);

            Assert.AreEqual(flag, getFunction);
        }

        [Test]
        public void registerSecondName()
        {
            bool flag = true;
            string name = "Jacob";
            bool getFunction = RegisterUserModel.checkEmail(name);

            Assert.AreEqual(flag, getFunction);
        }
    }
}

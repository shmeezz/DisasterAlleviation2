using Microsoft.VisualStudio.TestTools.UnitTesting;
using Disaster_Management_Website.Pages;

namespace MS_D_A_F_Testing
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void testListOfDisaster()
        {
            Disaster goods = new Disaster();
            DisasterModel v = new DisasterModel();
            v.getClass.Add(new Disaster("1", "2020-01-03", "2023-01-03", "Kzn", "Floods", "Food", ""));
            v.getClass.Add(new Disaster("2", "2021-01-03", "2023-01-03", "Johannesburg", "Volcano", "Clothes", ""));
            Assert.IsNotNull(v);
        }
        [TestMethod]
        public void testListOfDonatedMoney()
        {
            Money goods = new Money();
            MoneyModel v = new MoneyModel();
            v.getClass.Add(new Money("1", "2020-01-03", "R 30000", "NO", "For Clothes"));
            v.getClass.Add(new Money("2", "2021-01-03", "R 40000", "Yes", "For Food"));

            Assert.IsNotNull(v);
        }
        [TestMethod]
        public void testListOfDonatedGoods()
        {
            Goods goods = new Goods();
            GoodsModel v = new GoodsModel();
            v.getClass.Add(new Goods("1", "2020-01-03", "R 30000", "Clothes", "2021-02-08"));
            v.getClass.Add(new Goods("2", "2021-01-03", "R 40000", "Other", "2022-02-08"));

            Assert.IsNotNull(v);
        }

        [TestMethod]
        public void testPassword()
        {
            bool flag = true;
            string password = "www1234566";
            bool getFunction = LoginUserModel.checkUserPassword(password);

            Assert.AreEqual(flag, getFunction);

        }
        [TestMethod]
        public void testWrongPassword()
        {
            bool flag = false;
            string password = "www";
            bool getFunction = LoginUserModel.checkUserPassword(password);

            Assert.AreEqual(flag, getFunction);

        }
        [TestMethod]
        public void testEmail()
        {
            bool flag = true;
            string email = "jacob@gmail.yahoo";
            bool getFunction = LoginUserModel.checkuserName(email);

            Assert.AreEqual(flag, getFunction);

        }
        [TestMethod]
        public void testWrongEmail()
        {
            bool flag = false;
            string email = "@&@&&@&@&@&@&*@*@";
            bool getFunction = LoginUserModel.checkuserName(email);

            Assert.AreEqual(flag, getFunction);

        }

        [TestMethod]
        public void testRegisterEmail()
        {
            bool flag = true;
            string email = "jacob@gmail.com";
            bool getFunction = RegisterUserModel.checkEmail(email);

            Assert.AreEqual(flag, getFunction);

        }

        [TestMethod]
        public void testFalseRegisterEmail()
        {
            bool flag = false;
            string email = "@&@&&@&@&@&@&*@*@";
            bool getFunction = RegisterUserModel.checkEmail(email);

            Assert.AreEqual(flag, getFunction);
        }


        [TestMethod]
        public void testRegisterFirstName()
        {
            bool flag = true;
            string name = "Jacob";
            bool getFunction = RegisterUserModel.checkFirst(name);

            Assert.AreEqual(flag, getFunction);
        }

        [TestMethod]
        public void testFalseFirstName()
        {
            bool flag = false;
            string name = "@&@&&@&@&@&@&*@*@";
            bool getFunction = RegisterUserModel.checkEmail(name);

            Assert.AreEqual(flag, getFunction);
        }

        [TestMethod]
        public void registerFalseSecondName()
        {
            bool flag = false;
            string name = "*@&@&&@&@&@&@&*@*@";
            bool getFunction = RegisterUserModel.checkFirst(name);

            Assert.AreEqual(flag, getFunction);
        }

        [TestMethod]
        public void registerSecondName()
        {
            bool flag = true;
            string name = "Jacob";
            bool getFunction = RegisterUserModel.checkEmail(name);

            Assert.AreEqual(flag, getFunction);
        }
    }
}

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Disaster_Management_Website.Pages
{
    public class MoneyModel : PageModel
    {
        public List<Money> getClass = new List<Money>();
        public string hasData;
        public static SqlConnection sqlConnect;
        public static SqlCommand sqlCommand;
        SqlDataReader sqlData;
        public static string query = "";
        public void OnGet()
        {

            try
            {
                Database conn = new Database();
                sqlConnect = new SqlConnection(conn.database);

                sqlConnect.Open();
                query = "select* from MONEY_  where LOGIN_ID='" + LoginUserModel.user_ID + "'";
                sqlCommand = new SqlCommand(query, sqlConnect);
                sqlData = sqlCommand.ExecuteReader();

                while (sqlData.Read())
                {
                    getClass = viewDonate(sqlData);
                }
                sqlConnect.Close();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.ToString());
            }
        }

        public List<Money> viewDonate(SqlDataReader sqlData)
        {
            getClass.Add(new Money(sqlData["MONEY_ID"].ToString(), sqlData["DATE_OF_DONATION"].ToString(), sqlData["AMOUNT"].ToString(), sqlData["ANONYMOUS_"].ToString(), sqlData["COMMENT"].ToString()));
            return getClass;
        }
    }
    public class Money
    {
        public string rowID;
        public string date;
        public string amount;
        public string anonymous;
        public string comment;

        public Money()
        {

        }
        public Money(string row, string date, string amount, string ano, string comm)
        {
            this.rowID = row;
            this.date = date;
            this.amount = amount;
            this.anonymous = ano;
            this.comment = comm;
        }

        public string getRow()
        {
            return rowID;
        }
        public string getDate()
        {
            return date;
        }
        public string getAmount()
        {
            return amount;
        }
        public string getAnonymous()
        {
            return anonymous;
        }
        public string getComment()
        {
            return comment;
        }
    }
}

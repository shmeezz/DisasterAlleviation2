﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using DisasterAlleviation2022_version_2.Models;

namespace DisasterAlleviation2022_version_2.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<DisasterAlleviation2022_version_2.Models.Donations> Donations { get; set; }
        public DbSet<DisasterAlleviation2022_version_2.Models.GoodsDonations> GoodsDonations { get; set; }
        public DbSet<DisasterAlleviation2022_version_2.Models.Disaster> Disaster { get; set; }
    }
}
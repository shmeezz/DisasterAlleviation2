﻿namespace DisasterAlleviation2022_version_2.Models
{
    public class GoodsDonations
    {
        public int id { get; set; }
        public int clothesCategory { get; set; }
        public int PerishibleFoods { get; set; }
        public DateTime date { get; set; }
        public string NewCatergory { get; set; }
        public string description { get; set; }
        public string DonorName { get; set; }

        public GoodsDonations()
        {
                    
        }
    }
}
